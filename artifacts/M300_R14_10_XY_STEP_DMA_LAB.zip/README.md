# M300 Classic R14.10 XY STEP DMA Lab

This archive contains the compiled M300 Classic MCU application for the M300Boot
SD update. The lab image is `LAB_R14_10/M300APP.M3B`. The original R14.9 image
from the Orange Pi build is `ROLLBACK_R14_9/M300APP.M3B`. Install one image at
a time.

Source and build instructions are at https://github.com/MarcinKowalik-AGH/Zortrax-m300-Klipper/tree/ecd5b4cc3c782ed5f3b5f32da3fa81cc40607fca.
The build identifies itself as `0.13.14.10-XY-STEP-DMA-LAB`.

## Install

1. Finish any active print. Follow the same M300Boot SD update procedure used
   for R14.9. Copy `LAB_R14_10/M300APP.M3B` to the root of the FAT32 update
   card and flash from it.
2. Reconnect Klipper and check `ZORTRAX_MCU_STATUS` in Fluidd. Check that
   `mcu_release` matches the lab release above.
3. Keep the current Klipper R16.12 host, printer configuration and matching
   UART baud rate.

## First movement test

Use an empty platform with clearance and supervise the movement. Home the
printer and set up a clear X test stroke.

```gcode
G28
M400
G90
M220 S100
G1 Z10 F600
G1 X50 Y50 F6000
M400
```

Compare the physical end positions at 150 mm/s before trying 180 mm/s.
Run this block with `F9000` first. Once it completes and the platform and
carriage have clearance, repeat the block with `F10800`.

```gcode
G1 X255 F9000
M400
G1 X50 F6000
M400
```

Check `klippy.log` for `M300 XY STEP DMA completed first X block` and the
equivalent Y message when testing Y. Each appears once per MCU startup.

Proceed with 220, 260 and 300 mm/s only after the preceding speed completes
with repeatable physical positioning. At each new speed check X, Y and
diagonal motion. A logic analyzer on STEP is needed to verify actual pulse
width, interval and count. A Klipper-reported position alone cannot verify
mechanical position. If a move fails, end the test and keep `klippy.log`
before restarting. To restore R14.9, repeat the SD update with the rollback
image.

## What was tested

The register model replayed the two captured 180 mm/s block pairs and tested
300 mm/s timing, concurrent X and Y, timer wrap, pulse count, direction
changes, endstop interruption, emergency abort and DMA faults. GNU ARM built
and linked the image. The 25 software checks passed, including 375 host
tests and a real Klippy FILEOUTPUT run with the lab MCU dictionary.

The firmware uses finite DMA transfers for qualifying constant-period X/Y
STEP blocks. Other blocks use the existing software step scheduler. On the
timer launch writes, GNU ARM generated the same Thumb-2 stores for C and
handwritten assembly. Physical MCU execution and 300 mm/s operation on the
printer are pending hardware validation.
