# M300 Classic R14.14 earlier XY STEP timer handoff

The R14.13 diagonal move stopped with `Stepper too far in past` near the
planned X69.25 Y69.25 position. With 700 mm/s² acceleration, the equivalent
Klippy FILEOUTPUT move used 814-tick constant-period blocks there. The old
720-tick cutoff kept those blocks on software STEP. R14.14 allows periods up
to 1440 ticks. The replay enters hardware mode around X56.09 Y56.09.

The ARM build and 25 software checks passed. The register model interleaves
40 captured-planning blocks per axis on a shared clock, injects callback
latency and checks both pulse counts and positions. Hardware validation of
the diagonal move is pending. Source is at https://github.com/MarcinKowalik-AGH/Zortrax-m300-Klipper/tree/33b8b61ee267ab9170ab0974a7684fb7551ab38a.

## Install and check

Copy `M300APP.M3B` to the root of the FAT32 update card and use the existing
M300Boot application update procedure. In Fluidd, use `ZORTRAX_MCU_STATUS`
to check for `0.13.14.14-XY-STEP-TIMER-LAB`. In the current Klippy session,
verify `M300 XY STEP timer startup check axes=3` in `klippy.log` before motion.

## One diagonal reproduction

Use an empty platform and supervise the move. If it shuts down, save
`klippy.log` before restarting.

```gcode
G28
M400
G90
M220 S100
G1 Z5 F600
G1 X50 Y50 F6000
M400
G1 X255 Y255 F18000
M400
G1 X50 Y50 F6000
M400
```

Verify the physical arrival and return positions. A successful completion
is a hardware result for this motion profile.
