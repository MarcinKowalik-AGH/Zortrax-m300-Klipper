# M300 Classic R14.13 XY STEP timer build

`M300APP.M3B` is the compiled candidate for the Classic M300 M300Boot SD
update. Use the existing update procedure with this file in the root of
the FAT32 update card. Reconnect Klipper and check `ZORTRAX_MCU_STATUS` for
`0.13.14.13-XY-STEP-TIMER-LAB`. The source is at https://github.com/MarcinKowalik-AGH/Zortrax-m300-Klipper/tree/d0b3bf9be5688e6814f21810a6b1241f4c0b5ab7.

## Hardware check before movement

After Klipper configures the MCU, check the latest boot for
`M300 XY STEP timer startup check axes=3` in `klippy.log`. The MCU
runs this check with both STEP pins disconnected from timer output.
The value 3 means both internal counter gates stopped after four
compare events. A different value leaves hardware STEP disabled.
Use a current-session result and stop the motion test if it is missing
or differs from 3.

## Reproduce the original X stroke once

Use an empty platform, verify clearance and supervise the movement.

```gcode
G28
M400
G90
M220 S100
G1 Z5 F600
G1 X150 Y158 F6000
M400
G1 X255 F10800
M400
```

Check for `M300 XY STEP timer completed first X block`, successful
completion and physical arrival at X255. Save the log if motion faults.
Physical validation of the STEP pin, count and width, and validation at
higher speeds are still pending.

## Scope and validation

TIM2 and TIM3 generate the rising and falling STEP edges. TIM4 and TIM5
count the falling edges and gate the corresponding pulse timer. The
counter bounds the train without two independently rearmed DMA channels.
Klipper continues to schedule the first edge of each eligible block.
The software path handles the other blocks.

The ARM build and all 25 software checks passed, including a real
Klippy FILEOUTPUT run and a register model replay of the field ramps,
the alternating-period sequence, a maximum 65535-pulse block, delayed
callbacks, incomplete trains, stop, direction change and software
handoff. The model does not verify silicon propagation or pin routing.
