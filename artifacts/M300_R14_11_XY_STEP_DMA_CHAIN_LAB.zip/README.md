# M300 Classic R14.11 XY STEP DMA Chain Lab

This archive contains the compiled M300 Classic MCU application for the M300Boot
SD update. The lab image is `LAB_R14_11/M300APP.M3B`. The original R14.9 image
from the Orange Pi build is `ROLLBACK_R14_9/M300APP.M3B`. Install one image at
a time.

Source and build instructions are at https://github.com/MarcinKowalik-AGH/Zortrax-m300-Klipper/tree/61c99acceab73e471b8a3db1dd667c98a3b8827a.
The build identifies itself as `0.13.14.11-XY-STEP-DMA-CHAIN-LAB`.

## Install

1. Finish any active print. Follow the existing M300Boot SD update procedure.
   Copy `LAB_R14_11/M300APP.M3B` to the root of the FAT32 update card and
   flash from it.
2. Reconnect Klipper and run `ZORTRAX_MCU_STATUS` in Fluidd. Check that
   `mcu_release` matches the lab release above.
3. Keep the existing R16.12 host, printer configuration and matching UART
   baud rate.

## First movement test

Use an empty platform with clearance and supervise the movement. Home the
printer and set up a clear X test stroke.

```gcode
G28
M400
G90
M220 S100
G1 Z10 F600
G1 X50 Y50 F6000
M400
```

Check the physical end positions and the return mark at each speed. Run
the block below first at 180 mm/s. Then repeat with `F12000` for 200 mm/s,
followed by `F15600` for 260 mm/s. Run one block at a time.

```gcode
G1 X255 F10800
M400
G1 X50 F6000
M400
```

Check the current session in `klippy.log` for
`M300 XY STEP DMA chained first X boundary`. This message appears once per
MCU startup when a same-direction boundary is rearmed on the running timer.
Check Y separately after X. Proceed to 300 mm/s and diagonal tests only after
the 260 mm/s pass and a repeatable physical return. A logic analyzer on STEP
is needed to verify physical pulse width, period and count. If a move fails,
end the test and keep `klippy.log` before restarting. To restore R14.9,
repeat the SD update with the rollback image.

## Change and verification

The R14.10 capture at 260 mm/s contains X blocks alternating 433 and
432 timer ticks. Shutdown occurred about 1.01 ms after the nearest prior
block boundary. The 200 mm/s capture shows a corresponding pattern at
562 and 563 ticks. In R14.11, eligible same-direction blocks can rearm
both finite DMA channels while the timer keeps running. The existing
stop and start handoff handles blocks outside the safe rearm window.
The rearm checks the live motion gate and platform input. The periodic
guard checks host and temperature-sensor freshness and aborts active DMA
on a fault.

The register model replays both captured windows and checks phase, pulse
count, fallback, stop, wrap and shutdown. The full ARM builds and all
25 software checks passed, including 375 host tests and real Klippy
FILEOUTPUT with the new MCU dictionary. Physical execution and speed
qualification remain open.
