# M300 Classic R14.12 XY STEP DMA diagnostic

R14.12 is a diagnostic image. It retains the R14.11 movement logic and adds
a register snapshot when a DMA block completion triggers a shutdown.
The hardware failure is unresolved. Use this image only for a supervised
reproduction on an empty platform. Use the R14.9 rollback for regular use.

The lab image is `LAB_R14_12/M300APP.M3B`. The R14.9 rollback is
`ROLLBACK_R14_9/M300APP.M3B`. Copy one image at a time to the root of the
FAT32 update card and use the existing M300Boot SD update procedure.

Source and build instructions are at https://github.com/MarcinKowalik-AGH/Zortrax-m300-Klipper/tree/ffe27648d579e22f6cad86af4bfba156d358ef6b.
The build identifies itself as `0.13.14.12-XY-STEP-DMA-DIAG-LAB`.
Check `ZORTRAX_MCU_STATUS` after reconnecting.

## Single reproduction

Home the printer and position the toolhead at the original start point.
Then run the recorded 180 mm/s X stroke. Keep the platform empty and
supervise the test.

```gcode
G28
M400
G90
M220 S100
G1 Z5 F600
G1 X150 Y158 F6000
M400
G1 X255 F10800
M400
```

If it shuts down, save the log before restarting. On the Orange Pi run:

```bash
grep -nE 'M300 XY DMA fault|M300 XY DMA incomplete STEP block' \
  "$HOME/printer_data/logs/klippy.log" | tail -n 10
```

The diagnostic line reports `axis` (1 for X, 2 for Y), `chained` (1 if
rearmed on the running timer), remaining `rise` and `fall` transfers,
frozen timer `cnt`, `period`, `compare`, DMA `flags`, post-stop MCU
`clock`, scheduled completion `deadline`, and host-planned
`nominal_last` rising edge. If the move completes, record that result
and stop the diagnostic test there.

## Verification

The R14.11 trace points to a 290-step block at 669 ticks during acceleration.
The register model injects a missing falling transfer at that block and
checks that the recorded counts identify it and the channels are disabled.
The injected condition validates the diagnostic and does not establish the
cause of the physical failure. The ARM build and all 25 software checks
passed, including real Klippy FILEOUTPUT. Physical validation is pending.
