# Zortrax M300 Dual - 21 PCB photos

Reduced-size PNG photos (max 950px) for a compact GitHub download. Camera EXIF and GPS metadata removed. Original full-size photos available from the contributor.
